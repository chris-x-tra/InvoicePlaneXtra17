-- Einnahmekonto je Produktfamilie (Kontenrahmen, Modul account_chart; zuerst account_chart.sql ausfuehren)
ALTER TABLE `ip_families`
  ADD COLUMN `family_account_id` INT(11) NULL DEFAULT NULL,
  ADD KEY `idx_family_account` (`family_account_id`);
