<?php
// Diese Zeilen in application/language/german/ip_lang.php einfuegen (UTF-8, ohne BOM):

'account'                    => 'Konto',
'account_chart'              => 'Kontenrahmen',
'add_account'                => 'Konto hinzufügen',
'account_number'             => 'Kontonummer',
'account_number_hint'        => 'SKR03-Kontonummer, nur Ziffern (führende Nullen bleiben erhalten, z. B. 0420).',
'account_name'               => 'Kontobezeichnung',
'account_type'               => 'Art',
'account_type_income'        => 'Einnahme',
'account_type_expense'       => 'Ausgabe',
'account_type_all'           => 'Alle Arten',
'account_group'              => 'Gruppe',
'account_group_none'         => 'Ohne Gruppe',
'account_select'             => '– Konto wählen –',
'account_already_exists'     => 'Dieses Konto existiert bereits!',
'account_in_use'             => 'Das Konto wird von Ausgaben, Einnahme-Belegen oder Produktfamilien verwendet und kann nicht gelöscht werden.',
'account_type_locked'        => 'Die Art eines verwendeten Kontos kann nicht mehr geändert werden.',
'account_used_by'            => 'Dieses Konto wird %d-mal verwendet (Ausgaben, Einnahme-Belege, Produktfamilien).',
'filter_accounts'            => 'Konten filtern …',

// Die alten Kategorie-Texte werden nicht mehr verwendet und koennen entfallen:
// goods_receipt, third_party_services, work_equipment, operating_expenses,
// expenses_bank_statement, expenses_tax, expenses_tax_refund, receipt_type_income

// Produktfamilien: Einnahmekonto
'family_account'             => 'Einnahmekonto',
'family_account_none'        => '– kein Konto –',
'family_account_hint'        => 'Erlöse aus Rechnungspositionen dieser Familie werden in der EÜR auf dieses Konto gebucht.',
